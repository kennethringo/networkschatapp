# networkschatapp
This is a TCP java based chat application.
